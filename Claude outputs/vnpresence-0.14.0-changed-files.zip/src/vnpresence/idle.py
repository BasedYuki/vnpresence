"""Noticing that nobody is there.

The window in front answers "is the reader in the game?", and that is most of
the question - but not all of it. A novel left open on the monitor while its
reader makes dinner is still the window in front, and counting that hour as
reading is exactly the kind of quietly wrong number this project is trying not
to produce.

Windows keeps the answer ready: :c:func:`GetLastInputInfo` reports when any
keyboard or mouse input last reached the system, whichever program received it.
That is all that is read here - not what was typed, not where, not by which
program. There is no key logging and nothing to log.

Windows only, and dependency-free for the same reason as ``titlebar``.
Everywhere else this says "no idea", which the callers read as "keep counting"
rather than as a reason to stop.
"""

from __future__ import annotations

import logging
import sys

log = logging.getLogger(__name__)

#: GetTickCount is a 32-bit millisecond counter that wraps back to zero about
#: every 49.7 days of uptime. The subtraction below is done inside that width
#: on purpose, so a wrap between the last input and now produces the small
#: positive number it should rather than a 49-day idle time.
TICK_WIDTH = 0xFFFFFFFF


def supported() -> bool:
    return sys.platform == "win32"


def idle_seconds() -> float | None:
    """Seconds since the last keyboard or mouse input anywhere on this machine.

    ``None`` means there is no way to tell - not Windows, or the call failed.

    Two things it cannot see, both worth knowing about: input that went to a
    program running as administrator when VNPresence is not, and a game being
    advanced by something other than the keyboard and mouse. A novel in auto
    mode, read with a controller, is the case that matters for this project,
    which is why the threshold that uses this number is generous and can be
    switched off.
    """
    if not supported():
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class LastInputInfo(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]

        user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        user32.GetLastInputInfo.restype = wintypes.BOOL
        user32.GetLastInputInfo.argtypes = [ctypes.POINTER(LastInputInfo)]
        kernel32.GetTickCount.restype = wintypes.DWORD
        kernel32.GetTickCount.argtypes = []

        info = LastInputInfo()
        info.cbSize = ctypes.sizeof(LastInputInfo)
        if not user32.GetLastInputInfo(ctypes.byref(info)):
            return None
        elapsed = (int(kernel32.GetTickCount()) - int(info.dwTime)) & TICK_WIDTH
        return elapsed / 1000.0
    except Exception:  # pragma: no cover - defensive
        log.debug("could not read the last input time", exc_info=True)
        return None
